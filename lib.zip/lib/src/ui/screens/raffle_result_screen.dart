import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';

import '../../core/app_state.dart';
import '../../core/library_folders.dart';
import '../../core/models.dart';
import '../widgets/shared_player_panel.dart';
import '../widgets/tag_manager_dialog.dart';
import '../widgets/raffle_media_grid.dart';

class RaffleResultScreen extends StatefulWidget {
  final String segmentLabel;
  final List<MediaItem> items;
  final VoidCallback onSpinAgain;

  const RaffleResultScreen({
    super.key,
    required this.segmentLabel,
    required this.items,
    required this.onSpinAgain,
  });

  @override
  State<RaffleResultScreen> createState() => _RaffleResultScreenState();
}

class _RaffleResultScreenState extends State<RaffleResultScreen> {
  MediaItem? _selected;
  double _panelWidth = kPanelNormal;
  Set<String> _untaggedIds = {};

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _loadUntagged();
  }

  Future<void> _loadUntagged() async {
    final app = context.read<AppState>();
    if (!app.isReady || widget.items.isEmpty) return;
    final ids = await app.items!
        .listUntaggedItemIds(widget.items.map((e) => e.id).toList());
    if (mounted) setState(() => _untaggedIds = ids);
  }

  Future<void> _showTags(MediaItem item) async {
    final app = context.read<AppState>();
    final curSimple = await app.items!.listTagIdsForItem(item.id);
    final curKv = await app.items!.listKeyValueIdsForItem(item.id);
    final picked = await showTagManagerDialog(context,
        initialSimpleTagIds: curSimple, initialKeyValueIds: curKv);
    if (picked == null || !mounted) return;
    await app.setTagsForItem(
        itemId: item.id,
        simpleTagIds: picked.simpleTagIds,
        keyValueIds: picked.keyValueIds);
    await _loadUntagged();
  }

  Future<void> _exportItem(MediaItem item) async {
    final app = context.read<AppState>();
    final dir =
        await FilePicker.platform.getDirectoryPath(dialogTitle: 'Select directory');
    if (dir == null) return;
    final src =
        File(LibraryFolders.absPath(app.paths!.filesDir, item.storedRelPath));
    if (!await src.exists()) return;
    final dest = _uniquePath(p.join(dir, item.originalName));
    await src.copy(dest);
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Exported.')));
  }

  String _uniquePath(String basePath) {
    if (!File(basePath).existsSync()) return basePath;
    final dir = p.dirname(basePath);
    final name = p.basenameWithoutExtension(basePath);
    final ext = p.extension(basePath);
    var i = 1;
    while (true) {
      final cand = p.join(dir, '$name ($i)$ext');
      if (!File(cand).existsSync()) return cand;
      i++;
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const Icon(Icons.casino, size: 18),
            const SizedBox(width: 8),
            Flexible(
              child: Text('Result: ${widget.segmentLabel}',
                  overflow: TextOverflow.ellipsis),
            ),
            const SizedBox(width: 12),
            Text(
              '${widget.items.length} item${widget.items.length == 1 ? '' : 's'}',
              style: theme.textTheme.bodySmall,
            ),
          ],
        ),
        actions: [
          FilledButton.icon(
            onPressed: widget.onSpinAgain,
            icon: const Icon(Icons.refresh, size: 16),
            label: const Text('Spin Again'),
          ),
          const SizedBox(width: 12),
        ],
      ),
      body: widget.items.isEmpty
          ? _buildEmpty(context)
          : Row(
              children: [
                Expanded(
                  child: RaffleMediaGrid(
                    items: widget.items,
                    selected: _selected,
                    untaggedIds: _untaggedIds,
                    onSelect: (item) => setState(() => _selected = item),
                  ),
                ),
                if (_selected != null && app.isReady) ...[
                  const VerticalDivider(width: 1),
                  GestureDetector(
                    onHorizontalDragUpdate: (d) => setState(() {
                      _panelWidth =
                          (_panelWidth - d.delta.dx).clamp(220.0, 600.0);
                    }),
                    child: MouseRegion(
                      cursor: SystemMouseCursors.resizeColumn,
                      child: Container(width: 4, color: Colors.transparent),
                    ),
                  ),
                  SizedBox(
                    width: _panelWidth,
                    child: SharedPlayerPanel(
                      key: ValueKey(_selected!.id),
                      item: _selected!,
                      libraryFilesDir: app.paths!.filesDir,
                      thumbsDir: app.paths!.thumbsDir,
                      allItems: widget.items,
                      onTheatreChanged: (w) => setState(() => _panelWidth = w),
                      onOpen: () async {
                        final abs = LibraryFolders.absPath(
                            app.paths!.filesDir, _selected!.storedRelPath);
                        await OpenFilex.open(abs);
                      },
                      loadTags: () =>
                          app.items!.listTagsForItem(_selected!.id),
                      loadKeyValues: () =>
                          app.items!.listKeyValuesForItem(_selected!.id),
                    ),
                  ),
                ],
              ],
            ),
    );
  }

  Widget _buildEmpty(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.search_off, size: 48, color: cs.outline),
          const SizedBox(height: 16),
          const Text('No items matched this segment\'s filters.'),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: widget.onSpinAgain,
            icon: const Icon(Icons.refresh),
            label: const Text('Spin Again'),
          ),
        ],
      ),
    );
  }
}